#HOST = "irc.twitch.tv"
#HOST = "199.9.255.149"
#HOST = "199.9.251.213"
HOST = "irc.chat.twitch.tv"

#PORT = 443
PORT = 6667

PASS = "oauth:i8aqhr5387iaxr18qv7wvf5iu8suup"

# Bot's username
IDENT = "Lonelichan"

# List of channels to look at
#note, channel name must be lowercase
CHANNELLIST = ["fourswordkirby"]
